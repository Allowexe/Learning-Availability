package fr.isen.learning.interfaces.models.enums;


public enum FORMATIONSTATE {
    Planned,
    InProgress,
    Cancelled,
    Completed;
}
